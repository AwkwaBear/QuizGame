#ifndef END_H
#define END_H
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/OpenGL.hpp>
#include <iostream>

int end(sf::RenderWindow &window);

#endif
