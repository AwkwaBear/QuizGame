#ifndef ENTER_NAMES_H
#define ENTER_NAMES_H
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/OpenGL.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Audio/Sound.hpp>
#include <iostream>

int enter_names(sf::RenderWindow &window, int *px, std::vector<std::string> &names);

#endif
