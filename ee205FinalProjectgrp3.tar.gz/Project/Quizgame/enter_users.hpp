#ifndef ENTER_USERS_H
#define ENTER_USERS_H
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/OpenGL.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Audio/Sound.hpp>
#include <iostream>

int enter_users(sf::RenderWindow &window, int *px);

#endif
