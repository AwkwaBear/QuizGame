#ifndef INTRO_H
#define INTRO_H
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/OpenGL.hpp>
#include <iostream>


int intro(sf::RenderWindow &window);

#endif
